# YouTube Summarizer

This project extracts and summarizes the audio from a YouTube video using FastAPI, Whisper, and Transformers. Deployed using Kubernetes.