from pytube import YouTube
from moviepy.editor import AudioFileClip
from transformers import pipeline
import whisper
import os

def download_audio(url):
    yt = YouTube(url)
    stream = yt.streams.filter(only_audio=True).first()
    audio_path = stream.download(filename="audio.mp4")
    return audio_path

def transcribe_audio(audio_path):
    model = whisper.load_model("base")
    result = model.transcribe(audio_path)
    return result["text"]

def summarize_text(text):
    summarizer = pipeline("summarization", model="t5-small")
    return summarizer(text[:1000])[0]['summary_text']

def process_video(url):
    audio_path = download_audio(url)
    text = transcribe_audio(audio_path)
    summary = summarize_text(text)
    os.remove(audio_path)
    return summary
