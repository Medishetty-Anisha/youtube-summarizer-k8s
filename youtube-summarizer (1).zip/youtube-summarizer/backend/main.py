from fastapi import FastAPI, Query
from summarizer import process_video

app = FastAPI()

@app.get("/summarize")
def summarize_youtube_video(url: str = Query(...)):
    try:
        summary = process_video(url)
        return {"summary": summary}
    except Exception as e:
        return {"error": str(e)}
